package app.fern.vpn

import android.content.Context
import android.content.Intent
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Statistics
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyEncoding // <-- ДОБАВЛЕНО
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Random

enum class VpnState { DISCONNECTED, CONNECTING, CONNECTED, FAILED }

/**
 * Сгенерированный WARP-конфиг. Хранится в SharedPreferences (см. MainActivity).
 */
data class WarpConfig(
    val id: String,
    val name: String,
    val configText: String,
    val endpoint: String,
    val deviceId: String,
    val createdAt: Long,
    val pingMs: Int? = null
)

/**
 * Реальный VPN-сервис. Наследуется от GoBackend.VpnService — он сам отдаёт VpnService.Builder
 * и защищает сокеты WireGuard-туннеля. Реализует Tunnel, чтобы GoBackend мог сообщать о состоянии.
 */
class FernVpnService : GoBackend.VpnService(), Tunnel {

    private lateinit var backend: GoBackend
    private var lastRx: Long = 0
    private var lastTx: Long = 0

    override fun onCreate() {
        super.onCreate()
        backend = GoBackend(this)
        setOwner(backend)
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val cfg = pendingConfig
                if (cfg != null) {
                    try {
                        val config = Config.parse(BufferedReader(StringReader(cfg)))
                        backend.setState(this, Tunnel.State.UP, config)
                        state.value = VpnState.CONNECTED
                    } catch (e: Exception) {
                        state.value = VpnState.FAILED
                    }
                } else {
                    state.value = VpnState.FAILED
                }
            }
            ACTION_DISCONNECT -> {
                try {
                    backend.setState(this, Tunnel.State.DOWN, null)
                } catch (_: Exception) {
                }
                lastRx = 0
                lastTx = 0
                state.value = VpnState.DISCONNECTED
                stopSelf()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun getName(): String = TUNNEL_NAME

    override fun onStateChange(newState: Tunnel.State) {
        state.value = when (newState) {
            Tunnel.State.UP -> VpnState.CONNECTED
            Tunnel.State.DOWN -> VpnState.DISCONNECTED
            else -> VpnState.CONNECTING
        }
    }

    /** Скорость за последнюю секунду: (downBytes, upBytes). Вызывается из ViewModel раз в секунду. */
    fun speedBytesPerSecond(): Pair<Long, Long> {
        return try {
            val stats: Statistics = backend.getStatistics(this)
            val rx = stats.totalRx()
            val tx = stats.totalTx()
            val dr = if (lastRx == 0L) 0L else rx - lastRx
            val dt = if (lastTx == 0L) 0L else tx - lastTx
            lastRx = rx
            lastTx = tx
            dr.coerceAtLeast(0L) to dt.coerceAtLeast(0L)
        } catch (_: Exception) {
            0L to 0L
        }
    }

    companion object {
        const val ACTION_CONNECT = "app.fern.vpn.CONNECT"
        const val ACTION_DISCONNECT = "app.fern.vpn.DISCONNECT"
        private const val TUNNEL_NAME = "fern"

        val state = MutableStateFlow(VpnState.DISCONNECTED)

        @Volatile
        var pendingConfig: String? = null

        @Volatile
        var instance: FernVpnService? = null

        fun connect(ctx: Context, configText: String) {
            pendingConfig = configText
            state.value = VpnState.CONNECTING
            ctx.startService(Intent(ctx, FernVpnService::class.java).setAction(ACTION_CONNECT))
        }

        fun disconnect(ctx: Context) {
            ctx.startService(Intent(ctx, FernVpnService::class.java).setAction(ACTION_DISCONNECT))
        }
    }
}

/**
 * Регистрация в Cloudflare WARP: генерируем X25519-ключи, POSTим публичный на /reg,
 * из ответа собираем wg-quick конфиг. Работает на Dispatchers.IO.
 */
suspend fun generateWarpConfig(): WarpConfig? = withContext(Dispatchers.IO) {
    try {
        val kp = KeyPair()
        // ИСПРАВЛЕНО: используем KeyEncoding
        val pubKeyB64 = KeyEncoding.keyToBase64(kp.publicKey)
        val privKeyB64 = KeyEncoding.keyToBase64(kp.privateKey)

        val installId = randomString(22)
        val body = JSONObject().apply {
            put("key", pubKeyB64)
            put("install_id", installId)
            put("fcm_token", "$installId:APA91b${randomString(134)}")
            put("tos", "2023-01-01T00:00:00.000Z")
            put("model", "Android")
            // ИСПРАВЛЕНО: явно указываем String
            put("serial_number", "" as String)
            put("locale", "en_US")
        }.toString()

        val conn = URL("https://api.cloudflareclient.com/v0a2158/reg").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("User-Agent", "okhttp/3.12.1")
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.outputStream.use { it.write(body.toByteArray()) }

        val response = conn.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(response)
        val config = json.getJSONObject("config")
        val iface = config.getJSONObject("interface")
        val addresses = iface.getJSONObject("addresses")
        val v4 = addresses.getString("v4")
        val v6 = addresses.getString("v6")

        val peer = config.getJSONArray("peers").getJSONObject(0)
        val serverPub = peer.getString("public_key")
        val endpoint = peer.getJSONObject("endpoint")
        val host = endpoint.optString("host", "").ifEmpty { endpoint.optString("v4", "engage.cloudflareclient.com") }
        val port = endpoint.optJSONArray("ports")?.optInt(0, 2408) ?: 2408
        val deviceId = json.optString("id", installId)

        val configText = buildString {
            appendLine("[Interface]")
            appendLine("PrivateKey = $privKeyB64")
            appendLine("Address = $v4/32, $v6/128")
            appendLine("DNS = 1.1.1.1, 1.0.0.1")
            appendLine("[Peer]")
            appendLine("PublicKey = $serverPub")
            appendLine("AllowedIPs = 0.0.0.0/0, ::/0")
            appendLine("Endpoint = $host:$port")
        }

        WarpConfig(
            id = deviceId,
            name = "WARP #${(System.currentTimeMillis() % 10000)}",
            configText = configText,
            endpoint = "$host:$port",
            deviceId = deviceId,
            createdAt = System.currentTimeMillis()
        )
    } catch (e: Exception) {
        null
    }
}

/** Пинг до endpoint WARP (TCP connect, мс). null — если недоступен. */
suspend fun measurePing(endpoint: String): Int? = withContext(Dispatchers.IO) {
    try {
        val parts = endpoint.split(":")
        val host = parts[0]
        val port = parts.getOrNull(1)?.toIntOrNull() ?: 2408
        val start = System.currentTimeMillis()
        Socket().use { it.connect(InetSocketAddress(host, port), 3000) }
        (System.currentTimeMillis() - start).toInt()
    } catch (e: Exception) {
        null
    }
}

private fun randomString(len: Int): String {
    val chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    val rnd = Random()
    return (1..len).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
}