package app.fern.vpn

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.sin

/* ============================ Тема (тёмная, зелёно-лаймовая) ============================ */
/* Цвета заданы только в теме. В самом UI — исключительно MaterialTheme.colorScheme.* */

private val LimePrimary = Color(0xFFB4E34A)
private val MintSecondary = Color(0xFF8FD3B6)
private val BgDeep = Color(0xFF08140C)
private val SurfaceDark = Color(0xFF0F1F15)
private val SurfaceVariantDark = Color(0xFF172A1D)

@Composable
private fun FernTheme(dynamicColor: Boolean, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val colors = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        dynamicDarkColorScheme(context)
    } else {
        darkColorScheme(
            primary = LimePrimary,
            onPrimary = Color(0xFF1A2B05),
            primaryContainer = Color(0xFF2B4010),
            onPrimaryContainer = Color(0xFFD9F69B),
            secondary = MintSecondary,
            onSecondary = Color(0xFF0A2418),
            secondaryContainer = Color(0xFF1A3A2C),
            onSecondaryContainer = Color(0xFFC4F0DC),
            background = BgDeep,
            onBackground = Color(0xFFE7F1DD),
            surface = SurfaceDark,
            onSurface = Color(0xFFE7F1DD),
            surfaceVariant = SurfaceVariantDark,
            onSurfaceVariant = Color(0xFFB9CDAA),
            error = Color(0xFFFF8A80),
            onError = Color(0xFF3B0000),
            tertiary = Color(0xFFFFD166)
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}

/* ============================ Анимированный «живой» фон ============================ */

@Composable
private fun AnimatedBackground() {
    val cs = MaterialTheme.colorScheme
    val infinite = rememberInfiniteTransition(label = "bg")
    val gradOffset by infinite.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse),
        label = "grad"
    )
    val blob1 by infinite.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "blob1"
    )
    val blob2 by infinite.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(13000, easing = LinearEasing), RepeatMode.Reverse),
        label = "blob2"
    )
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            Brush.linearGradient(
                colors = listOf(cs.background, cs.surface, cs.surfaceVariant, cs.background),
                start = Offset(w * gradOffset, 0f),
                end = Offset(w * (1f - gradOffset), h)
            )
        )
        drawCircle(
            Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.16f), Color.Transparent)),
            radius = w * 0.55f,
            center = Offset(w * (0.15f + 0.6f * blob1), h * (0.22f + 0.18f * sin(blob1 * 6.283f)))
        )
        drawCircle(
            Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.14f), Color.Transparent)),
            radius = w * 0.5f,
            center = Offset(w * (0.85f - 0.55f * blob2), h * (0.75f - 0.25f * blob2))
        )
    }
}

/* ============================ Питомец Ферн (травка с ножками) ============================ */

@Composable
private fun FernPet(connected: Boolean, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val infinite = rememberInfiniteTransition(label = "pet")
    val sway by infinite.animateFloat(
        -6f, 6f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "sway"
    )
    val zAlpha by infinite.animateFloat(
        0.2f, 1f,
        infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "z"
    )
    val jump = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    Box(modifier, contentAlignment = Alignment.TopEnd) {
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    rotationZ = sway
                    translationY = -jump.value
                }
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    scope.launch {
                        jump.snapTo(0f)
                        jump.animateTo(
                            42f,
                            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
                        )
                        jump.animateTo(0f)
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            val body = cs.primary
            val blade = cs.primaryContainer
            val face = cs.onPrimary

            // ножки
            drawRoundRect(
                face,
                topLeft = Offset(w * 0.34f, h * 0.76f),
                size = Size(w * 0.10f, h * 0.20f),
                cornerRadius = CornerRadius(w * 0.05f)
            )
            drawRoundRect(
                face,
                topLeft = Offset(w * 0.56f, h * 0.76f),
                size = Size(w * 0.10f, h * 0.20f),
                cornerRadius = CornerRadius(w * 0.05f)
            )
            // основание травки
            drawRect(body, topLeft = Offset(w * 0.20f, h * 0.52f), size = Size(w * 0.60f, h * 0.28f))
            drawCircle(body, radius = w * 0.28f, center = Offset(w * 0.32f, h * 0.52f))
            drawCircle(body, radius = w * 0.32f, center = Offset(w * 0.50f, h * 0.46f))
            drawCircle(body, radius = w * 0.28f, center = Offset(w * 0.68f, h * 0.52f))
            // три острых листика сверху
            fun blade(cx: Float, top: Float, bw: Float, bh: Float) {
                val p = Path().apply {
                    moveTo(cx - bw / 2, h * 0.42f)
                    lineTo(cx + bw / 2, h * 0.42f)
                    lineTo(cx, top)
                    close()
                }
                drawPath(p, blade)
            }
            blade(w * 0.35f, h * 0.18f, w * 0.16f, h * 0.24f)
            blade(w * 0.50f, h * 0.10f, w * 0.18f, h * 0.32f)
            blade(w * 0.65f, h * 0.20f, w * 0.16f, h * 0.22f)

            val eyeY = h * 0.46f
            if (connected) {
                // открытые глаза + улыбка
                drawCircle(face, radius = w * 0.045f, center = Offset(w * 0.40f, eyeY))
                drawCircle(face, radius = w * 0.045f, center = Offset(w * 0.60f, eyeY))
                drawArc(
                    face, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(w * 0.38f, h * 0.50f),
                    size = Size(w * 0.24f, h * 0.14f),
                    style = Stroke(width = w * 0.025f)
                )
            } else {
                // закрытые глаза (дуги) + ротик-палка
                drawArc(
                    face, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(w * 0.34f, eyeY - h * 0.02f),
                    size = Size(w * 0.12f, h * 0.07f),
                    style = Stroke(width = w * 0.022f)
                )
                drawArc(
                    face, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(w * 0.54f, eyeY - h * 0.02f),
                    size = Size(w * 0.12f, h * 0.07f),
                    style = Stroke(width = w * 0.022f)
                )
                drawLine(
                    face,
                    start = Offset(w * 0.44f, h * 0.58f),
                    end = Offset(w * 0.56f, h * 0.58f),
                    strokeWidth = w * 0.022f
                )
            }
        }
        if (!connected) {
            Text(
                "Z z z",
                color = cs.onSurfaceVariant,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.graphicsLayer { alpha = zAlpha; translationY = -10f * zAlpha }
            )
        }
    }
}

/* ============================ Мини-график скорости (анимированная волна) ============================ */

@Composable
private fun SpeedGraph(speedBps: Long, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val samples = remember { mutableStateListOf<Float>() }
    LaunchedEffect(speedBps) {
        samples.add((speedBps / 500_000f).coerceIn(0f, 1f))
        while (samples.size > 32) samples.removeAt(0)
    }
    val phase by rememberInfiniteTransition(label = "wave").animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val n = samples.size.coerceAtLeast(2)
        val path = Path()
        for (i in 0 until n) {
            val v = if (i < samples.size) samples[i] else 0f
            val x = w * i / (n - 1)
            val y = h * 0.85f - v * h * 0.7f + sin((i * 0.6f + phase * 6.283f)).toFloat() * h * 0.04f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val fill = Path().apply {
            addPath(path)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(fill, Brush.verticalGradient(listOf(cs.primary.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(path, cs.primary, style = Stroke(width = 3f))
    }
}

/* ============================ QR-код через Canvas (кодирует ZXing, рисует Canvas) ============================ */

@Composable
private fun QrCodeView(text: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val matrix = remember(text) {
        try {
            val hints = mapOf(
                EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
                EncodeHintType.MARGIN to 1
            )
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 256, 256, hints)
        } catch (e: Exception) {
            null
        }
    }
    Canvas(modifier) {
        drawRect(cs.surface)
        if (matrix == null) return@Canvas
        val cell = size.width / matrix.width
        for (y in 0 until matrix.height) {
            for (x in 0 until matrix.width) {
                if (matrix.get(x, y)) {
                    drawRect(
                        cs.onSurface,
                        topLeft = Offset(x * cell, y * cell),
                        size = Size(cell, cell)
                    )
                }
            }
        }
    }
}

/* ============================ ViewModel (всё в одном файле) ============================ */

class FernViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("fern_prefs", Context.MODE_PRIVATE)

    val connectionState = MutableStateFlow(FernVpnService.state.value)
    val configs = MutableStateFlow(loadConfigs())
    val selectedConfigId = MutableStateFlow(
        prefs.getString("selected_config", null) ?: loadConfigs().firstOrNull()?.id
    )
    val isGenerating = MutableStateFlow(false)
    val ping = MutableStateFlow<Int?>(null)
    val speedDown = MutableStateFlow(0L)
    val speedUp = MutableStateFlow(0L)
    val showPet = MutableStateFlow(prefs.getBoolean("show_pet", true))
    val dynamicColors = MutableStateFlow(prefs.getBoolean("dynamic_colors", false))
    val autoConnect = MutableStateFlow(prefs.getBoolean("auto_connect", false))
    val onboardingDone = MutableStateFlow(prefs.getBoolean("onboarding_done", false))
    val errorMessage = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch {
            FernVpnService.state.collect { connectionState.value = it }
        }
        viewModelScope.launch {
            while (true) {
                val inst = FernVpnService.instance
                if (inst != null && connectionState.value == VpnState.CONNECTED) {
                    val (d, u) = inst.speedBytesPerSecond()
                    speedDown.value = d
                    speedUp.value = u
                } else {
                    speedDown.value = 0
                    speedUp.value = 0
                }
                delay(1000)
            }
        }
        viewModelScope.launch {
            delay(800)
            if (autoConnect.value && configs.value.isNotEmpty() &&
                FernVpnService.state.value == VpnState.DISCONNECTED
            ) {
                val cfg = configs.value.firstOrNull { it.id == selectedConfigId.value } ?: configs.value.first()
                if (VpnService.prepare(app) == null) {
                    ping.value = cfg.pingMs
                    FernVpnService.connect(app, cfg.configText)
                }
            }
        }
    }

    fun generateConfig() {
        viewModelScope.launch {
            isGenerating.value = true
            val cfg = generateWarpConfig()
            if (cfg != null) {
                val pinged = cfg.copy(pingMs = measurePing(cfg.endpoint))
                configs.value = configs.value + pinged
                saveConfigs(configs.value)
                if (selectedConfigId.value == null) selectConfig(pinged.id)
            } else {
                errorMessage.value = "Не удалось сгенерировать конфиг. Проверьте интернет и повторите."
            }
            isGenerating.value = false
        }
    }

    fun selectConfig(id: String) {
        selectedConfigId.value = id
        prefs.edit().putString("selected_config", id).apply()
    }

    fun deleteConfig(id: String) {
        configs.value = configs.value.filterNot { it.id == id }
        saveConfigs(configs.value)
        if (selectedConfigId.value == id) selectedConfigId.value = configs.value.firstOrNull()?.id
    }

    fun togglePet(v: Boolean) {
        showPet.value = v
        prefs.edit().putBoolean("show_pet", v).apply()
    }

    fun toggleDynamic(v: Boolean) {
        dynamicColors.value = v
        prefs.edit().putBoolean("dynamic_colors", v).apply()
    }

    fun toggleAuto(v: Boolean) {
        autoConnect.value = v
        prefs.edit().putBoolean("auto_connect", v).apply()
    }

    fun finishOnboarding() {
        onboardingDone.value = true
        prefs.edit().putBoolean("onboarding_done", true).apply()
    }

    fun clearError() {
        errorMessage.value = null
    }

    private fun loadConfigs(): List<WarpConfig> {
        val str = prefs.getString("configs", null) ?: return emptyList()
        return try {
            val arr = JSONArray(str)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                WarpConfig(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    configText = o.getString("configText"),
                    endpoint = o.getString("endpoint"),
                    deviceId = o.optString("deviceId", ""),
                    createdAt = o.optLong("createdAt", 0L),
                    pingMs = if (o.isNull("pingMs")) null else o.getInt("pingMs")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveConfigs(list: List<WarpConfig>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name)
                    .put("configText", c.configText)
                    .put("endpoint", c.endpoint)
                    .put("deviceId", c.deviceId)
                    .put("createdAt", c.createdAt)
                    .put("pingMs", c.pingMs)
            )
        }
        prefs.edit().putString("configs", arr.toString()).apply()
    }
}

/* ============================ Activity ============================ */

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#08140C")
        window.navigationBarColor = android.graphics.Color.parseColor("#08140C")
        setContent {
            val vm: FernViewModel = viewModel()
            val dynamic by vm.dynamicColors.collectAsState()
            FernTheme(dynamic) {
                Box(Modifier.fillMaxSize()) {
                    AnimatedBackground()
                    FernApp(vm)
                }
            }
        }
    }
}

@Composable
private fun FernApp(vm: FernViewModel) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var showOnboarding by remember { mutableStateOf(!vm.onboardingDone.value) }
    var showSupport by remember { mutableStateOf(false) }
    var qrConfig by remember { mutableStateOf<WarpConfig?>(null) }

    val state by vm.connectionState.collectAsState()
    val configs by vm.configs.collectAsState()
    val showPet by vm.showPet.collectAsState()
    val error by vm.errorMessage.collectAsState()

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val cfg = configs.firstOrNull { it.id == vm.selectedConfigId.value } ?: configs.firstOrNull()
            if (cfg != null) {
                vm.ping.value = cfg.pingMs
                FernVpnService.connect(context, cfg.configText)
            }
        }
    }

    val onConnectClick: () -> Unit = {
        if (state == VpnState.CONNECTED || state == VpnState.CONNECTING) {
            vm.ping.value = null
            FernVpnService.disconnect(context)
        } else {
            val cfg = configs.firstOrNull { it.id == vm.selectedConfigId.value } ?: configs.firstOrNull()
            if (cfg == null) {
                vm.errorMessage.value = "Сначала сгенерируйте конфиг во вкладке «Конфиги»."
                tab = 1
            } else {
                val prepareIntent = VpnService.prepare(context)
                if (prepareIntent != null) {
                    vpnPermissionLauncher.launch(prepareIntent)
                } else {
                    vm.ping.value = cfg.pingMs
                    FernVpnService.connect(context, cfg.configText)
                }
            }
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)) {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Главная") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.List, contentDescription = null) },
                    label = { Text("Конфиги") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("Настройки") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm, onConnectClick, showPet)
                1 -> ConfigsScreen(vm, onShare = { qrConfig = it })
                else -> SettingsScreen(vm, onSupport = { showSupport = true })
            }
        }
    }

    if (showOnboarding) {
        AlertDialog(
            onDismissRequest = { showOnboarding = false; vm.finishOnboarding() },
            confirmButton = {
                TextButton(onClick = { showOnboarding = false; vm.finishOnboarding() }) { Text("Понятно") }
            },
            title = { Text("Привет!") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FernPet(connected = false, Modifier.size(120.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Привет! Я Ферн. Нажми кнопку, чтобы подключиться.")
                }
            }
        )
    }

    if (showSupport) {
        SupportDialog { showSupport = false }
    }

    if (qrConfig != null) {
        AlertDialog(
            onDismissRequest = { qrConfig = null },
            confirmButton = { TextButton(onClick = { qrConfig = null }) { Text("Закрыть") } },
            title = { Text("QR конфига: ${qrConfig!!.name}") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    QrCodeView(qrConfig!!.configText, Modifier.size(220.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Отсканируйте в WireGuard-клиенте",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        )
    }

    if (error != null) {
        AlertDialog(
            onDismissRequest = { vm.clearError() },
            confirmButton = { TextButton(onClick = { vm.clearError() }) { Text("ОК") } },
            title = { Text("Внимание") },
            text = { Text(error!!) }
        )
    }
}

/* ============================ Экран «Главная» ============================ */

@Composable
private fun HomeScreen(vm: FernViewModel, onConnectClick: () -> Unit, showPet: Boolean) {
    val cs = MaterialTheme.colorScheme
    val state by vm.connectionState.collectAsState()
    val ping by vm.ping.collectAsState()
    val down by vm.speedDown.collectAsState()
    val up by vm.speedUp.collectAsState()
    val connected = state == VpnState.CONNECTED

    val pulseScale by rememberInfiniteTransition(label = "pulse").animateFloat(
        1f, 1.55f,
        infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "pulseScale"
    )

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showPet) {
            FernPet(connected = connected, modifier = Modifier.size(140.dp))
            Spacer(Modifier.height(8.dp))
        }

        Text(
            text = when (state) {
                VpnState.CONNECTED -> "Подключено"
                VpnState.CONNECTING -> "Подключение…"
                VpnState.FAILED -> "Ошибка подключения"
                else -> "Отключено"
            },
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))

        Surface(
            color = cs.surfaceVariant,
            shape = RoundedCornerShape(50)
        ) {
            Text(
                "Пинг: ${ping?.let { "$it мс" } ?: "—"}",
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 7.dp),
                style = MaterialTheme.typography.labelMedium
            )
        }

        Spacer(Modifier.height(28.dp))

        Box(contentAlignment = Alignment.Center) {
            if (connected) {
                Box(
                    Modifier
                        .size(190.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(cs.primary.copy(alpha = 0.18f))
                )
            }
            Button(
                onClick = onConnectClick,
                shape = CircleShape,
                modifier = Modifier.size(180.dp),
                contentPadding = PaddingValues(0.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (connected) cs.primary else cs.surfaceVariant,
                    contentColor = if (connected) cs.onPrimary else cs.onSurfaceVariant
                )
            ) {
                Icon(Icons.Filled.Power, contentDescription = null, modifier = Modifier.size(72.dp))
            }
        }

        Spacer(Modifier.height(28.dp))

        Surface(
            color = cs.surface,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Скорость трафика", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "↓ ${formatSpeed(down)}   ↑ ${formatSpeed(up)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.primary
                )
                Spacer(Modifier.height(8.dp))
                SpeedGraph(down, Modifier.fillMaxWidth().height(80.dp))
            }
        }
    }
}

/* ============================ Экран «Конфиги» ============================ */

@Composable
private fun ConfigsScreen(vm: FernViewModel, onShare: (WarpConfig) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val configs by vm.configs.collectAsState()
    val generating by vm.isGenerating.collectAsState()
    val selected by vm.selectedConfigId.collectAsState()

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Конфиги", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))

        Button(
            onClick = { vm.generateConfig() },
            enabled = !generating,
            shape = RoundedCornerShape(32.dp),
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            if (generating) {
                CircularProgressIndicator(Modifier.size(20.dp), color = cs.onPrimary, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Генерация WARP…")
            } else {
                Icon(Icons.Filled.Cloud, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text("Сгенерировать WARP")
            }
        }

        Spacer(Modifier.height(16.dp))

        if (configs.isEmpty()) {
            Text(
                "Пока нет конфигов. Нажмите кнопку выше — я сгенерирую бесплатный WARP.",
                color = cs.onSurfaceVariant
            )
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(configs, key = { it.id }) { cfg ->
                Surface(
                    color = if (cfg.id == selected) cs.primaryContainer else cs.surface,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.selectConfig(cfg.id) }
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(cfg.name, fontWeight = FontWeight.Bold)
                            Text(
                                cfg.endpoint,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                            Text(
                                "Пинг: ${cfg.pingMs?.let { "$it мс" } ?: "—"}" +
                                    if (cfg.id == selected) "  •  активен" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.primary
                            )
                        }
                        IconButton(onClick = { onShare(cfg) }) {
                            Icon(Icons.Filled.QrCode2, contentDescription = "Поделиться", tint = cs.secondary)
                        }
                        IconButton(onClick = { vm.deleteConfig(cfg.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Удалить", tint = cs.error)
                        }
                    }
                }
            }
        }
    }
}

/* ============================ Экран «Настройки» ============================ */

@Composable
private fun SettingsScreen(vm: FernViewModel, onSupport: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dyn by vm.dynamicColors.collectAsState()
    val pet by vm.showPet.collectAsState()
    val auto by vm.autoConnect.collectAsState()
    val dynSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Настройки", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        SwitchRow(
            title = "Динамические цвета Material You",
            subtitle = if (dynSupported) "Работает на Android 12+" else "Доступно на Android 12+",
            checked = dyn,
            enabled = dynSupported
        ) { vm.toggleDynamic(it) }

        SwitchRow(
            title = "Показывать питомца",
            subtitle = "Травка Ферн на главном экране",
            checked = pet,
            enabled = true
        ) { vm.togglePet(it) }

        SwitchRow(
            title = "Автоподключение",
            subtitle = "Подключаться при запуске приложения",
            checked = auto,
            enabled = true
        ) { vm.toggleAuto(it) }

        Spacer(Modifier.height(14.dp))

        Button(
            onClick = onSupport,
            shape = RoundedCornerShape(32.dp),
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = cs.secondary, contentColor = cs.onSecondary)
        ) {
            Icon(Icons.Filled.Favorite, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Text("Поддержать проект")
        }

        Spacer(Modifier.weight(1f))
        Text(
            "Версия 1.0t",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChecked: (Boolean) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        color = cs.surface,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            Switch(checked = checked, onCheckedChange = onChecked, enabled = enabled)
        }
    }
}

@Composable
private fun SupportDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val card = "2202 2082 0005 1788"
    var copied by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("card", card))
                copied = true
            }) { Text(if (copied) "Скопировано!" else "Копировать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } },
        title = { Text("Поддержать проект") },
        text = {
            Column {
                Text("Спасибо, что поддерживаешь Ферн! Реквизиты карты:")
                Spacer(Modifier.height(12.dp))
                Surface(color = cs.primaryContainer, shape = RoundedCornerShape(16.dp)) {
                    Text(
                        card,
                        modifier = Modifier.padding(18.dp),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    )
}

private fun formatSpeed(bytes: Long): String = when {
    bytes >= 1_000_000 -> "%.1f МБ/с".format(bytes / 1_000_000.0)
    bytes >= 1_000 -> "%.0f КБ/с".format(bytes / 1_000.0)
    else -> "$bytes Б/с"
}
